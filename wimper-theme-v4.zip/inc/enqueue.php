<?php
/**
 * Enqueue scripts and styles.
 *
 * @package wimper_Theme
 */

if (!defined('ABSPATH')) {
        exit; // Exit if accessed directly.
}

/**
 * Determine whether map assets should be enqueued.
 */
function wimper_should_load_maps()
{
        $should_load_maps = is_post_type_archive('location') || is_singular('location') || is_page('locations');

        if (is_front_page() && function_exists('wimper_home_locations_preview')) {
                $locations_preview = wimper_home_locations_preview();
                $should_load_maps = $should_load_maps || (!empty($locations_preview['map_points']));
        }

        return $should_load_maps;
}

/**
 * Enqueue theme styles and scripts
 */
function wimper_enqueue_assets()
{
        // DEBUG: Confirm this function is executing
        echo '<!-- DEBUG: wimper_enqueue_assets is running -->';

        $script_dependencies = array('jquery');

        // Font Awesome (Subset)
        $fa_path = wimper_THEME_DIR . '/assets/css/font-awesome-subset.css';
        $fa_version = file_exists($fa_path) ? filemtime($fa_path) : '6.4.0';
        wp_enqueue_style(
                'wimper-font-awesome',
                wimper_THEME_URI . '/assets/css/font-awesome-subset.css',
                array(),
                $fa_version,
                'all'
        );


        if (is_front_page()) {
                $chart_js_path = wimper_THEME_DIR . '/assets/js/chart.min.js';
                $chart_js_version = file_exists($chart_js_path) ? filemtime($chart_js_path) : '4.4.1';

                wp_enqueue_script(
                        'chartjs',
                        wimper_THEME_URI . '/assets/js/chart.min.js',
                        array(),
                        $chart_js_version,
                        true
                );

                wp_script_add_data('chartjs', 'defer', true);
                $script_dependencies[] = 'chartjs';
        }

        // Compiled Tailwind CSS.
        $css_path = wimper_THEME_DIR . '/assets/css/main.css';
        $css_version = file_exists($css_path) ? filemtime($css_path) : wimper_VERSION;

        // Compiled Tailwind CSS - loads synchronously
        wp_enqueue_style(
                'wimper-main',
                wimper_THEME_URI . '/assets/css/main.css',
                array(),
                $css_version,
                'all'
        );

        // Dequeue legacy main CSS on front page to prevent WIMPER style overrides
        if (is_front_page()) {
                wp_dequeue_style('wimper-main');
        }

        // Main Theme Stylesheet (style.css)
        wp_enqueue_style(
                'wimper-style',
                get_stylesheet_uri(),
                array(),
                $css_version,
                'all'
        );

        // CRITICAL ACCESSIBILITY FIXES (Injected Inline to bypass cache/build)
        $custom_css = "
                /* Darkened Brand Colors for WCAG AA Compliance (Enhanced) */
                .text-wimper-red { color: #964030 !important; }
                .bg-wimper-red { background-color: #964030 !important; }
                .text-wimper-orange { color: #A8551E !important; }
                .bg-wimper-orange { background-color: #A8551E !important; }
                .text-wimper-green { color: #4D5C54 !important; }
                .bg-wimper-green { background-color: #4D5C54 !important; }
                .text-wimper-yellow { color: #8C6B2F !important; }
                .bg-wimper-yellow { background-color: #8C6B2F !important; }
                
                /* Footer Social Links - Touch Target Fix (48px) */
                footer .flex.gap-3 a {
                        width: 48px !important;
                        height: 48px !important;
                        display: flex !important;
                        align-items: center !important;
                        justify-content: center !important;
                }
                footer .flex.gap-3 a i {
                        font-size: 1.25rem !important;
                }
                
                /* Footer Navigation Links - Touch Target Fix */
                footer nav a {
                        display: inline-block !important;
                        min-height: 48px !important;
                        min-width: 48px !important;
                        padding: 12px 16px !important;
                        line-height: 1.5 !important;
                        display: flex !important;
                        align-items: center !important;
                }
                
                /* Review Carousel Dots - Touch Target Fix (48px) */
                [data-reviews-dots] button {
                        min-width: 48px !important;
                        min-height: 48px !important;
                        padding: 12px !important;
                }

                /* Global Button Touch Targets */
                a[class*='px-8'][class*='py-4'], 
                button[class*='px-8'][class*='py-4'] {
                        min-height: 48px !important;
                        display: inline-flex !important;
                        align-items: center !important;
                        justify-content: center !important;
                }

                /* Form Inputs Touch Targets */
                input[type='text'],
                input[type='email'],
                input[type='tel'],
                input[type='number'],
                select,
                textarea {
                        min-height: 48px !important;
                        font-size: 16px !important; /* Prevent iOS zoom */
                }
                
                /* Form Labels - Ensure visibility if hidden */
                .wimper-tour-form label {
                        display: block !important;
                        color: #263238 !important; /* Brand Ink */
                        opacity: 1 !important;
                        margin-bottom: 0.5rem !important;
                }

                        /* Force CTA Button Visibility */
                        header .container > a[href*='contact'] {
                                display: flex !important;
                        }
                }

                /* Accessibility: Increase contrast for muted text */
                .text-brand-ink\/60 { color: rgba(38, 50, 56, 0.9) !important; }
                .text-brand-ink\/70 { color: rgba(38, 50, 56, 0.95) !important; }
        ";
        wp_add_inline_style('wimper-main', $custom_css);

        // Main JavaScript.
        $js_path = wimper_THEME_DIR . '/assets/js/main.js';
        $js_version = file_exists($js_path) ? filemtime($js_path) : wimper_VERSION;

        wp_enqueue_script(
                'wimper-main-js',
                wimper_THEME_URI . '/assets/js/main.js',
                $script_dependencies,
                $js_version,
                true
        );

        // DEBUG: Confirm script was enqueued
        echo '<!-- DEBUG: Enqueued wimper-main-js with URL: ' . wimper_THEME_URI . '/assets/js/main.js and version: ' . $js_version . ' -->';

        // Defer re-enabled for FCP optimization
        wp_script_add_data('wimper-main-js', 'defer', true);

        // Map Facade (Lazy Load Leaflet).
        $should_load_maps = wimper_should_load_maps();

        if ($should_load_maps) {
                wp_enqueue_script(
                        'wimper-map-facade',
                        wimper_THEME_URI . '/assets/js/map-facade.js',
                        array('wimper-main-js'), // Depend on main to ensure kidazzleData is available
                        $js_version,
                        true
                );
                wp_script_add_data('wimper-map-facade', 'defer', true);
        }

        // Localize script for AJAX and dynamic data.
        wp_localize_script(
                'wimper-main-js',
                'kidazzleData',
                array(
                        'ajaxUrl' => admin_url('admin-ajax.php'),
                        'nonce' => wp_create_nonce('wimper_nonce'),
                        'themeUrl' => wimper_THEME_URI,
                        'homeUrl' => home_url(),
                )
        );
}
add_action('wp_enqueue_scripts', 'wimper_enqueue_assets');



/**
 * Add resource hints for external assets to improve initial page performance.
 */
function wimper_resource_hints($urls, $relation_type)
{
        if ('preconnect' === $relation_type) {

                if (is_front_page() || is_singular('program') || is_post_type_archive('program')) {
                        $urls[] = 'https://cdn.jsdelivr.net';
                }

                if (wimper_should_load_maps()) {
                        $urls[] = 'https://unpkg.com';
                }

                // Preconnect to external origins identified in audit
                $urls[] = 'https://widgets.leadconnectorhq.com';
                $urls[] = 'https://services.leadconnectorhq.com';
                $urls[] = 'https://images.leadconnectorhq.com';
                $urls[] = 'https://stcdn.leadconnectorhq.com';
                $urls[] = 'https://fonts.bunny.net';
        }

        if ('dns-prefetch' === $relation_type) {

                if (is_front_page() || is_singular('program') || is_post_type_archive('program')) {
                        $urls[] = '//cdn.jsdelivr.net';
                }

                if (wimper_should_load_maps()) {
                        $urls[] = '//unpkg.com';
                }
                $urls[] = '//widgets.leadconnectorhq.com';
                $urls[] = '//services.leadconnectorhq.com';
                $urls[] = '//images.leadconnectorhq.com';
                $urls[] = '//stcdn.leadconnectorhq.com';
                $urls[] = '//fonts.bunny.net';
        }

        return array_unique($urls, SORT_REGULAR);
}
add_filter('wp_resource_hints', 'wimper_resource_hints', 10, 2);

/**
 * Enqueue admin assets
 */
function wimper_enqueue_admin_assets($hook)
{
        // Only load on post edit screens
        if ('post.php' !== $hook && 'post-new.php' !== $hook) {
                return;
        }

        // Font Awesome for icon previews in admin (using local version)
        $fa_path = wimper_THEME_DIR . '/assets/css/font-awesome.css';
        $fa_version = file_exists($fa_path) ? filemtime($fa_path) : '6.4.0';

        wp_enqueue_style(
                'font-awesome-admin',
                wimper_THEME_URI . '/assets/css/font-awesome.css',
                array(),
                $fa_version // Use same version as frontend for consistency
        );

        // Media uploader
        wp_enqueue_media();

        // Custom admin script for media uploader
        wp_enqueue_script(
                'wimper-admin',
                wimper_THEME_URI . '/assets/js/admin.js',
                array('jquery'),
                wimper_VERSION,
                true
        );
}
add_action('admin_enqueue_scripts', 'wimper_enqueue_admin_assets');

/**
 * Async load CSS for fonts only (not main CSS to prevent FOUC)
 */
function wimper_async_styles($html, $handle, $href, $media)
{
        // Defer Font Awesome AND Main CSS (Critical CSS inlined in header)
        if (in_array($handle, array('wimper-font-awesome'))) {
                // Add data-no-optimize to prevent LiteSpeed from combining/blocking this file
                $html = str_replace('<link', '<link data-no-optimize="1"', $html);

                // If media is 'all', swap to 'print' and add onload
                $html = str_replace("media='all'", "media='print' onload=\"this.media='all'\"", $html);
                // If media is already 'print' (rare but possible), ensure onload is present
                $html = str_replace("media='print'", "media='print' onload=\"this.media='all'\"", $html);

                // Add fallback for no-js
                $html .= "<noscript><link rel='stylesheet' href='{$href}' media='all'></noscript>";
        }
        return $html;
}
add_filter('style_loader_tag', 'wimper_async_styles', 10, 4);

/**
 * Dequeue Dashicons for non-logged in users to improve performance
 */
function wimper_dequeue_dashicons()
{
        if (!is_user_logged_in()) {
                wp_dequeue_style('dashicons');
                wp_deregister_style('dashicons');
        }
}
add_action('wp_enqueue_scripts', 'wimper_dequeue_dashicons');


/**
 * Dequeue CDN styles (specifically Font Awesome) to force local loading.
 * Runs at priority 100 to ensure it runs after plugins.
 */
function wimper_dequeue_cdn_styles()
{
        global $wp_styles;
        if (empty($wp_styles->queue)) {
                return;
        }

        foreach ($wp_styles->queue as $handle) {
                if (!isset($wp_styles->registered[$handle])) {
                        continue;
                }

                $src = $wp_styles->registered[$handle]->src;

                // Check if it's Font Awesome and coming from a CDN
                if (
                        (strpos($handle, 'font-awesome') !== false || strpos($handle, 'fontawesome') !== false || strpos($handle, 'fa-') !== false) &&
                        (strpos($src, 'cdnjs') !== false || strpos($src, 'cloudflare') !== false || strpos($src, 'jsdelivr') !== false)
                ) {
                        wp_dequeue_style($handle);
                        wp_deregister_style($handle);
                }
        }
}
add_action('wp_enqueue_scripts', 'wimper_dequeue_cdn_styles', 100);
